document.addEventListener('DOMContentLoaded', () => {

	console.log('script.js работает');
	
})